package com.bokchi.diet_memo

data class DataModel (

    val date : String = "",
    val memo : String = ""

)